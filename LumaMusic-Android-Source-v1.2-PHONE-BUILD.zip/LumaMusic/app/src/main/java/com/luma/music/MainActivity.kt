package com.luma.music

import android.Manifest
import android.content.pm.PackageManager
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF09090D)
private val Panel = Color(0xFF17171F)
private val Glass = Color(0xB8292934)
private val Muted = Color(0xFFA6A6B3)
private val Accent = Color(0xFFC9B8FF)

class MainActivity : ComponentActivity() {
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            val controller = runCatching { future.get() }.getOrNull()
            runOnUiThread {
                setContent {
                    if (controller != null) LumaApp(controller)
                    else MaterialTheme(colorScheme = darkColorScheme()) {
                        Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
                            Text("Unable to connect to the playback service. Please restart LUMA.", color = Color.White)
                        }
                    }
                }
            }
        }, mainExecutor)
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LumaApp(player: Player) {
    val context = LocalContext.current
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var permissionGranted by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf<Track?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("Songs") }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var quality by remember { mutableStateOf<AudioQuality?>(null) }
    var lyricLines by remember { mutableStateOf(emptyList<LyricLine>()) }
    var search by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf("Title") }
    var showSleepDialog by remember { mutableStateOf(false) }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var sleepAtTrackEnd by remember { mutableStateOf(false) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var playlists by remember { mutableStateOf(loadPlaylists(context)) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var showQueueInfo by remember { mutableStateOf(false) }
    var showTextSettings by remember { mutableStateOf(false) }
    var textScale by remember { mutableFloatStateOf(context.getSharedPreferences("luma_library", 0).getFloat("text_scale", 1f)) }

    fun savePlaylists(value: Map<String, List<Long>>) {
        playlists = value
        val root = JSONObject()
        value.forEach { (name, ids) -> root.put(name, JSONArray(ids)) }
        context.getSharedPreferences("luma_library", 0).edit().putString("playlists", root.toString()).apply()
    }
    fun scan() { tracks = Library.scan(context) }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) scan()
    }
    LaunchedEffect(Unit) {
        permissionGranted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (permissionGranted) scan() else launcher.launch(permission)
    }
    DisposableEffect(player, tracks) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val uri = mediaItem?.localConfiguration?.uri
                current = tracks.firstOrNull { it.uri == uri } ?: current
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) {
        while (true) {
            isPlaying = player.isPlaying
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it > 0 } ?: 1L
            delay(250)
        }
    }
    LaunchedEffect(current) {
        quality = current?.let { track -> withContext(Dispatchers.IO) { FlacQuality.read(context, track.uri) } }
        lyricLines = current?.let { track -> withContext(Dispatchers.IO) { Lyrics.readEmbeddedFlac(context, track) } } ?: emptyList()
    }
    val currentLyric = lyricLines.lastOrNull { it.timeMs <= position }?.text.orEmpty()
    LaunchedEffect(sleepMinutes) {
        if (sleepMinutes > 0) {
            delay(sleepMinutes * 60_000L)
            player.pause(); sleepMinutes = 0
        }
    }
    DisposableEffect(player, sleepAtTrackEnd) {
        val timerListener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (sleepAtTrackEnd && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                    player.pause(); sleepAtTrackEnd = false
                }
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (sleepAtTrackEnd && playbackState == Player.STATE_ENDED) {
                    player.pause(); sleepAtTrackEnd = false
                }
            }
        }
        player.addListener(timerListener)
        onDispose { player.removeListener(timerListener) }
    }

    val visibleTracks = remember(tracks, search, sortMode) {
        val filtered = tracks.filter { (it.title + it.artist + it.album + it.path).contains(search, true) }
        when (sortMode) {
            "Artist" -> filtered.sortedBy { it.artist.lowercase() }
            "Album" -> filtered.sortedBy { it.album.lowercase() }
            "Duration" -> filtered.sortedBy { it.duration }
            else -> filtered.sortedBy { it.title.lowercase() }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Accent, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Ink)) {
            if (showPlayer && current != null) {
                NowPlayingScreen(
                    track = current!!, player = player, isPlaying = isPlaying, position = position,
                    duration = duration, quality = quality, currentLyric = currentLyric, onBack = { showPlayer = false },
                    onPrevious = { playRelative(-1, visibleTracks, current, player) { current = it } },
                    onNext = { playRelative(1, visibleTracks, current, player) { current = it } },
                    onSeek = { player.seekTo(it) }
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 14.dp, top = 22.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("LUMA", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                            Text("Your music, locally.", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { showSleepDialog = true }) { Icon(Icons.Default.Bedtime, "Sleep timer", tint = if (sleepMinutes > 0 || sleepAtTrackEnd) Accent else Muted) }
                        IconButton(onClick = { showQueueInfo = true }) { Icon(Icons.Default.QueueMusic, "Queue", tint = Muted) }
                        IconButton(onClick = { showTextSettings = true }) { Icon(Icons.Default.Tune, "Display settings", tint = Muted) }
                        IconButton(onClick = { sortMode = when (sortMode) { "Title" -> "Artist"; "Artist" -> "Album"; "Album" -> "Duration"; else -> "Title" } }) { Icon(Icons.Default.Sort, "Sort: $sortMode", tint = Muted) }
                        IconButton(onClick = { scan() }) { Icon(Icons.Default.Refresh, "Rescan", tint = Muted) }
                    }
                    if (!permissionGranted) {
                        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.MusicNote, null, tint = Accent, modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(12.dp)); Text("Allow music access", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text("LUMA needs access to your local audio library.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp)); Button(onClick = { launcher.launch(permission) }) { Text("Grant access") }
                        }
                    } else {
                        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), placeholder = { Text("Search your library", color = Muted) }, singleLine = true, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF30303A), focusedBorderColor = Accent, unfocusedContainerColor = Panel, focusedContainerColor = Panel))
                        Spacer(Modifier.height(13.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("Songs", "Albums", "Artists", "Folders", "Playlists").forEach { item ->
                                FilterChip(selected = tab == item, onClick = { tab = item }, label = { Text(item, fontSize = 11.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF393247), selectedLabelColor = Color.White, labelColor = Muted), border = FilterChipDefaults.filterChipBorder(enabled = true, selected = tab == item, borderColor = Color(0xFF393944), selectedBorderColor = Color.Transparent))
                            }
                        }
                        when (tab) {
                            "Albums" -> LibraryGroups(visibleTracks, group = { it.album }, onPick = { group -> visibleTracks.filter { it.album == group }.firstOrNull()?.let { startTrack(it, visibleTracks.filter { t -> t.album == group }, player) { current = it } } })
                            "Artists" -> LibraryGroups(visibleTracks, group = { it.artist }, onPick = { group -> visibleTracks.filter { it.artist == group }.firstOrNull()?.let { startTrack(it, visibleTracks.filter { t -> t.artist == group }, player) { current = it } } })
                            "Folders" -> LibraryGroups(visibleTracks, group = { it.path.trimEnd('/').substringAfterLast('/').ifBlank { "Music" } }, onPick = { group -> visibleTracks.filter { it.path.trimEnd('/').substringAfterLast('/').ifBlank { "Music" } == group }.firstOrNull()?.let { startTrack(it, visibleTracks.filter { t -> t.path.trimEnd('/').substringAfterLast('/').ifBlank { "Music" } == group }, player) { current = it } } })
                            "Playlists" -> PlaylistScreen(
                                playlists = playlists,
                                tracks = tracks,
                                onCreate = { showCreatePlaylist = true },
                                onPlay = { name ->
                                    val list = playlists[name].orEmpty().mapNotNull { id -> tracks.firstOrNull { it.id == id } }
                                    list.firstOrNull()?.let { startTrack(it, list, player) { current = it } }
                                },
                                onDelete = { name -> savePlaylists(playlists - name) }
                            )
                            else -> LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 112.dp)) {
                                item { Text("${visibleTracks.size} TRACKS  ·  SORTED BY $sortMode".uppercase(), color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 5.dp, bottom = 9.dp)) }
                                items(visibleTracks, key = { it.id }) { track ->
                                    TrackRow(
                                        track = track, selected = current?.id == track.id, textScale = textScale,
                                        playlistNames = playlists.keys.toList(),
                                        onClick = { startTrack(track, visibleTracks, player) { current = it } },
                                        onQueue = { player.addMediaItem(track.toMediaItem()) },
                                        onPlayNext = { val insertAt = (player.currentMediaItemIndex + 1).coerceAtLeast(0); player.addMediaItem(insertAt, track.toMediaItem()) },
                                        onAddPlaylist = { name -> savePlaylists(playlists + (name to (playlists[name].orEmpty() + track.id).distinct())) },
                                        onCreatePlaylist = { showCreatePlaylist = true }
                                    )
                                }
                                if (visibleTracks.isEmpty()) item { EmptyLibrary(tracks.isEmpty()) }
                            }
                        }
                    }
                }
                AnimatedVisibility(visible = current != null, modifier = Modifier.align(Alignment.BottomCenter)) {
                    current?.let { track -> MiniPlayer(
                        track, isPlaying, player, currentLyric, (position.toFloat() / duration.coerceAtLeast(1)).coerceIn(0f, 1f),
                        onOpen = { showPlayer = true },
                        onToggle = { if (player.isPlaying) player.pause() else player.play() },
                        onNext = { player.seekToNextMediaItem() },
                        onShuffle = { val next = !shuffleEnabled; shuffleEnabled = next; player.shuffleModeEnabled = next },
                        onRepeat = { val next = when (repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }; repeatMode = next; player.repeatMode = next }
                    ) }
                }
            }
        }
    }

    if (showSleepDialog) AlertDialog(
        onDismissRequest = { showSleepDialog = false },
        title = { Text("Sleep timer") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Pause playback automatically", color = Muted, fontSize = 13.sp)
            listOf(5, 10, 15, 30, 45, 60, 90).forEach { minutes ->
                TextButton(onClick = { sleepMinutes = minutes; sleepAtTrackEnd = false; showSleepDialog = false }) { Text("$minutes minutes") }
            }
            TextButton(onClick = { sleepAtTrackEnd = true; sleepMinutes = 0; showSleepDialog = false }) { Text("At the end of this track") }
            TextButton(onClick = { sleepMinutes = 0; sleepAtTrackEnd = false; showSleepDialog = false }) { Text("Turn timer off") }
        } }, confirmButton = { TextButton(onClick = { showSleepDialog = false }) { Text("Close") } }
    )
    if (showCreatePlaylist) AlertDialog(
        onDismissRequest = { showCreatePlaylist = false; newPlaylistName = "" },
        title = { Text("Create playlist") },
        text = { OutlinedTextField(value = newPlaylistName, onValueChange = { newPlaylistName = it }, label = { Text("Playlist name") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { val name = newPlaylistName.trim(); if (name.isNotEmpty()) savePlaylists(playlists + (name to playlists[name].orEmpty())); newPlaylistName = ""; showCreatePlaylist = false }) { Text("Create") } },
        dismissButton = { TextButton(onClick = { showCreatePlaylist = false; newPlaylistName = "" }) { Text("Cancel") } }
    )
    if (showTextSettings) AlertDialog(
        onDismissRequest = { showTextSettings = false },
        title = { Text("Display settings") },
        text = { Column {
            Text("Library text size · ${(textScale * 100).toInt()}%", color = Muted)
            Slider(value = textScale, onValueChange = { textScale = it }, valueRange = 0.85f..1.35f, steps = 9)
        } },
        confirmButton = { TextButton(onClick = { context.getSharedPreferences("luma_library", 0).edit().putFloat("text_scale", textScale).apply(); showTextSettings = false }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { showTextSettings = false }) { Text("Close") } }
    )
    if (showQueueInfo) AlertDialog(
        onDismissRequest = { showQueueInfo = false }, title = { Text("Playback queue") },
        text = { Text("${player.mediaItemCount} tracks in the current queue. Use a song's ⋮ menu to add it to the queue or play it next.", color = Muted) },
        confirmButton = { TextButton(onClick = { showQueueInfo = false }) { Text("Done") } }
    )
}

private fun loadPlaylists(context: android.content.Context): Map<String, List<Long>> = try {
    val raw = context.getSharedPreferences("luma_library", 0).getString("playlists", "{}") ?: "{}"
    val root = JSONObject(raw)
    buildMap { root.keys().forEach { name -> val arr = root.optJSONArray(name) ?: JSONArray(); put(name, (0 until arr.length()).map { arr.getLong(it) }) } }
} catch (_: Exception) { emptyMap() }

@Composable
private fun EmptyLibrary(isEmpty: Boolean) {
    Column(Modifier.fillMaxWidth().padding(top = 90.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.MusicNote, null, tint = Accent, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(12.dp)); Text(if (isEmpty) "Your library is quiet" else "No matching tracks", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(if (isEmpty) "Add music to your device, then tap rescan." else "Try another search.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun TrackRow(track: Track, selected: Boolean, textScale: Float, playlistNames: List<String>, onClick: () -> Unit, onQueue: () -> Unit, onPlayNext: () -> Unit, onAddPlaylist: (String) -> Unit, onCreatePlaylist: () -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(if (selected) Color(0xFF211E2B) else Color.Transparent).padding(start = 8.dp, end = 2.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f).clickable(onClick = onClick).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(track.albumArt, 49); Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = if (selected) Accent else Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = (14 * textScale).sp)
                Text("${track.artist}  ·  ${track.album}", color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = (11 * textScale).sp)
            }
            Text(track.durationLabel, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 7.dp))
        }
        Box {
            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Track actions", tint = Muted) }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(text = { Text("Play") }, onClick = { menuOpen = false; onClick() })
                DropdownMenuItem(text = { Text("Play next") }, leadingIcon = { Icon(Icons.Default.SkipNext, null) }, onClick = { menuOpen = false; onPlayNext() })
                DropdownMenuItem(text = { Text("Add to queue") }, leadingIcon = { Icon(Icons.Default.QueueMusic, null) }, onClick = { menuOpen = false; onQueue() })
                HorizontalDivider()
                if (playlistNames.isEmpty()) DropdownMenuItem(text = { Text("Create playlist") }, leadingIcon = { Icon(Icons.Default.Add, null) }, onClick = { menuOpen = false; onCreatePlaylist() })
                else {
                    playlistNames.forEach { name -> DropdownMenuItem(text = { Text("Add to $name", maxLines = 1) }, leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) }, onClick = { menuOpen = false; onAddPlaylist(name) }) }
                    DropdownMenuItem(text = { Text("New playlist…") }, onClick = { menuOpen = false; onCreatePlaylist() })
                }
            }
        }
    }
}

@Composable
private fun PlaylistScreen(playlists: Map<String, List<Long>>, tracks: List<Track>, onCreate: () -> Unit, onPlay: (String) -> Unit, onDelete: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("YOUR PLAYLISTS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f)); TextButton(onClick = onCreate) { Icon(Icons.Default.Add, null); Text("New") } } }
        items(playlists.keys.toList(), key = { it }) { name ->
            val count = playlists[name].orEmpty().count { id -> tracks.any { it.id == id } }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onPlay(name) }.padding(vertical = 10.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF292438)), contentAlignment = Alignment.Center) { Icon(Icons.Default.QueueMusic, null, tint = Accent) }
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.SemiBold); Text("$count tracks", color = Muted, fontSize = 11.sp) }
                TextButton(onClick = { onDelete(name) }) { Text("Delete", color = Muted) }
            }
        }
        if (playlists.isEmpty()) item { EmptyLibrary(false); Text("Create a playlist, then use a song's ⋮ menu to add tracks.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp)) }
    }
}

@Composable
private fun LibraryGroups(tracks: List<Track>, group: (Track) -> String, onPick: (String) -> Unit) {
    val groups = tracks.groupBy(group).toSortedMap(String.CASE_INSENSITIVE_ORDER)
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
        item { Text("${groups.size} COLLECTIONS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.padding(start = 4.dp, bottom = 12.dp)) }
        items(groups.keys.toList()) { name ->
            val first = groups[name]?.firstOrNull()
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).clickable { onPick(name) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(first?.albumArt, 54); Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Medium, maxLines = 1); Text("${groups[name]?.size ?: 0} tracks", color = Muted, fontSize = 11.sp) }
                Icon(Icons.Default.ArrowBack, null, tint = Muted, modifier = Modifier.size(17.dp))
            }
        }
        if (groups.isEmpty()) item { EmptyLibrary(tracks.isEmpty()) }
    }
}

@Composable
private fun Cover(uri: android.net.Uri?, size: Int) {
    if (uri != null) AsyncImage(model = uri, contentDescription = "Album artwork", contentScale = ContentScale.Crop, modifier = Modifier.size(size.dp).clip(RoundedCornerShape(12.dp)))
    else Box(Modifier.size(size.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF48405B), Color(0xFF1C2634)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color(0xFFD6C9FF)) }
}

@Composable
private fun MiniPlayer(track: Track, playing: Boolean, player: Player, currentLyric: String, progress: Float, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit, onShuffle: () -> Unit, onRepeat: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp).clip(RoundedCornerShape(22.dp)).background(Glass).clickable(onClick = onOpen).padding(horizontal = 10.dp, vertical = 7.dp)) {
        if (currentLyric.isNotBlank()) Text(currentLyric, color = Accent, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp))
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(2.dp).clip(CircleShape), color = Accent, trackColor = Color.White.copy(alpha = .12f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Cover(track.albumArt, 43); Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) { Text(track.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(track.artist, color = Muted, fontSize = 10.sp, maxLines = 1) }
        IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, "Shuffle", tint = if (player.shuffleModeEnabled) Accent else Muted, modifier = Modifier.size(18.dp)) }
        IconButton(onClick = onRepeat) { Icon(Icons.Default.Repeat, "Repeat", tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) Accent else Muted, modifier = Modifier.size(18.dp)) }
        IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = Color.White) }
        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
}

@Composable
private fun NowPlayingScreen(track: Track, player: Player, isPlaying: Boolean, position: Long, duration: Long, quality: AudioQuality?, currentLyric: String, onBack: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit) {
    val progress = (position.toFloat() / duration.coerceAtLeast(1)).coerceIn(0f, 1f)
    Box(Modifier.fillMaxSize().background(Ink)) {
        if (track.albumArt != null) {
            AsyncImage(model = track.albumArt, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().blur(65.dp))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xAA08080D), Color(0xDD09090D), Ink))))
        } else Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF342D46), Ink, Ink))))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 25.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Spacer(Modifier.weight(1f)); Text("NOW PLAYING", fontSize = 10.sp, letterSpacing = 3.sp, color = Color.White.copy(alpha = .75f)); Spacer(Modifier.weight(1f))
                Icon(Icons.Default.GraphicEq, null, tint = Accent, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.weight(.7f))
            AsyncImage(model = track.albumArt, contentDescription = "${track.album} artwork", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(25.dp)))
            Spacer(Modifier.height(32.dp))
            Text(track.title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp)); Text(track.artist, fontSize = 15.sp, color = Color.White.copy(alpha = .68f), maxLines = 1)
            Spacer(Modifier.height(24.dp))
            if (currentLyric.isNotBlank()) Text(currentLyric, color = Accent, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth())
            Slider(value = progress, onValueChange = { onSeek((it * duration).toLong()) }, modifier = Modifier.fillMaxWidth().height(24.dp), colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = .25f)))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(time(position), color = Muted, fontSize = 10.sp); Text("-${time((duration - position).coerceAtLeast(0))}", color = Muted, fontSize = 10.sp) }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.align(Alignment.CenterHorizontally).clip(CircleShape).background(Glass).padding(horizontal = 13.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(if (quality != null) Color(0xFF83D8B0) else Color(0xFFFFC978)))
                Spacer(Modifier.width(7.dp)); Text(quality?.label ?: if (track.mimeType?.contains("flac", true) == true) "LOSSLESS" else "LOCAL AUDIO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                if (quality != null) { Spacer(Modifier.width(8.dp)); Text(quality.detail, color = Muted, fontSize = 9.sp) }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(52.dp)) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(32.dp)) }
                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }, modifier = Modifier.size(72.dp).clip(CircleShape).background(Color.White)) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = Ink, modifier = Modifier.size(40.dp)) }
                IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(32.dp)) }
            }
            Spacer(Modifier.weight(1f))
            Text("ON THIS DEVICE", color = Color.White.copy(alpha = .35f), fontSize = 9.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 15.dp))
        }
    }
}

private fun time(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
    .setUri(uri)
    .setMediaMetadata(
        androidx.media3.common.MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(albumArt)
            .build()
    )
    .build()
private fun startTrack(track: Track, queue: List<Track>, player: Player, setCurrent: (Track) -> Unit) {
    val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
    player.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
    player.prepare(); player.play(); setCurrent(track)
}
private fun playRelative(delta: Int, queue: List<Track>, current: Track?, player: Player, setCurrent: (Track) -> Unit) {
    if (queue.isEmpty() || current == null) return
    val index = queue.indexOfFirst { it.id == current.id }
    val next = (index + delta).coerceIn(0, queue.lastIndex)
    val track = queue[next]
    player.seekTo(next, 0L); player.play(); setCurrent(track)
}
