package com.luma.music

import android.content.Context

 data class LyricLine(val timeMs: Long, val text: String)

object Lyrics {
    /** Reads synced LRC-style lyrics stored in common FLAC Vorbis-comment fields. */
    fun readEmbeddedFlac(context: Context, track: Track): List<LyricLine> {
        if (track.mimeType?.contains("flac", true) != true && !track.fileName.endsWith(".flac", true)) return emptyList()
        return try {
            context.contentResolver.openInputStream(track.uri)?.use { input ->
                val magic = ByteArray(4)
                if (input.read(magic) != 4 || String(magic, Charsets.US_ASCII) != "fLaC") return emptyList()
                var found: String? = null
                var last = false
                var blocks = 0
                while (!last && blocks++ < 128) {
                    val header = ByteArray(4)
                    if (input.read(header) != 4) break
                    last = (header[0].toInt() and 0x80) != 0
                    val type = header[0].toInt() and 0x7F
                    val length = ((header[1].toInt() and 0xFF) shl 16) or ((header[2].toInt() and 0xFF) shl 8) or (header[3].toInt() and 0xFF)
                    if (length < 0 || length > 8 * 1024 * 1024) break
                    if (type == 4) {
                        val data = ByteArray(length)
                        var offset = 0
                        while (offset < length) { val n = input.read(data, offset, length - offset); if (n <= 0) break; offset += n }
                        if (offset == length) found = parseVorbisLyrics(data)
                        break
                    } else {
                        var remaining = length
                        while (remaining > 0) { val skipped = input.skip(remaining.toLong()).toInt(); if (skipped <= 0) { if (input.read() < 0) break else remaining-- } else remaining -= skipped }
                    }
                }
                found?.let { parseLrc(it) } ?: emptyList()
            } ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }

    private fun parseVorbisLyrics(data: ByteArray): String? {
        var p = 0
        fun readLe(): Int {
            if (p + 4 > data.size) return -1
            val n = (data[p].toInt() and 255) or ((data[p + 1].toInt() and 255) shl 8) or ((data[p + 2].toInt() and 255) shl 16) or ((data[p + 3].toInt() and 255) shl 24)
            p += 4; return n
        }
        val vendorLength = readLe(); if (vendorLength < 0 || vendorLength > data.size - p) return null
        p += vendorLength
        val count = readLe(); if (count < 0 || count > 10000) return null
        repeat(count) {
            val size = readLe(); if (size < 0 || size > data.size - p) return null
            val field = String(data, p, size, Charsets.UTF_8); p += size
            val split = field.indexOf('=')
            if (split > 0) {
                val key = field.substring(0, split).uppercase()
                if (key in setOf("LYRICS", "SYNCEDLYRICS", "UNSYNCEDLYRICS", "LYRICS_ENG", "LYRICS_EN")) return field.substring(split + 1)
            }
        }
        return null
    }

    fun parseLrc(raw: String): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        val pattern = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]""")
        raw.lineSequence().forEach { line ->
            val matches = pattern.findAll(line).toList()
            if (matches.isEmpty()) return@forEach
            val text = line.substringAfter(matches.last().value).trim().ifBlank { line.substring(matches.last().range.last + 1).trim() }
            matches.forEach { m ->
                val minutes = m.groupValues[1].toLongOrNull() ?: 0L
                val seconds = m.groupValues[2].toLongOrNull() ?: 0L
                val fraction = m.groupValues[3]
                val millis = when (fraction.length) { 1 -> (fraction.toLongOrNull() ?: 0L) * 100; 2 -> (fraction.toLongOrNull() ?: 0L) * 10; else -> fraction.toLongOrNull() ?: 0L }
                result += LyricLine(minutes * 60_000 + seconds * 1_000 + millis, text)
            }
        }
        if (result.isEmpty() && raw.isNotBlank()) return listOf(LyricLine(0L, raw.trim().replace('\n', ' ')))
        return result.sortedBy { it.timeMs }
    }
}
