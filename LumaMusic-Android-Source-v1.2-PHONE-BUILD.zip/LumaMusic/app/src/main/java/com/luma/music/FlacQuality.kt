package com.luma.music

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

object FlacQuality {
    /** Reads the FLAC STREAMINFO block from the local file. Returns null for non-FLAC or inaccessible files. */
    fun read(context: Context, uri: Uri): AudioQuality? {
        return try {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
        pfd.use { descriptor ->
            FileInputStream(descriptor.fileDescriptor).use { input ->
                val header = ByteArray(42)
                var offset = 0
                while (offset < header.size) {
                    val n = input.read(header, offset, header.size - offset)
                    if (n < 0) return null
                    offset += n
                }
                if (String(header, 0, 4, Charsets.US_ASCII) != "fLaC") return null
                val blockType = header[4].toInt() and 0x7F
                if (blockType != 0) return null
                var packed = 0L
                for (i in 18..25) packed = (packed shl 8) or (header[i].toLong() and 0xFF)
                val sampleRate = ((packed ushr 44) and 0xFFFFF).toInt()
                val bits = (((packed ushr 36) and 0x1F) + 1).toInt()
                val kind = if (sampleRate > 48000 || bits > 16) "HI-RES LOSSLESS" else "LOSSLESS"
                AudioQuality(kind, "FLAC · ${bits}-bit · ${sampleRate} Hz")
            }
        }
        } catch (_: Exception) { null }
    }
}
