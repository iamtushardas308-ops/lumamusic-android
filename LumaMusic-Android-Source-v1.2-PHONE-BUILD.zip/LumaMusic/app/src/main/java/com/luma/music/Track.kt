package com.luma.music

import android.content.ContentUris
import android.net.Uri

 data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val albumArt: Uri?,
    val path: String,
    val mimeType: String?,
    val fileName: String = ""
) {
    val albumArtOrNull: Uri? get() = albumArt
    val durationLabel: String get() {
        val seconds = duration / 1000
        return "%d:%02d".format(seconds / 60, seconds % 60)
    }
    companion object {
        fun albumArtUri(albumId: Long): Uri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
    }
}

data class AudioQuality(val label: String, val detail: String)
