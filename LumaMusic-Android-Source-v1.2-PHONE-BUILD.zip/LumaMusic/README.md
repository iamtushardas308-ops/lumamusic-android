# LUMA Music — local player project

A dark, offline-first Android music player starter project designed around a MusicBeat-like library workflow, a lightweight BitChord-inspired mini-player, and a restrained Liquid Glass visual style. Version 1.2.0 moves playback into an AndroidX Media3 MediaSessionService.

## Implemented in this revision

- Opens to the local **Songs** library. Tapping a song starts playback and **keeps the user on the current library tab**; it does not navigate to the full-screen player.
- Optional full-screen player opens only when the mini-player is tapped.
- Local library tabs: Songs, Albums, Artists, Folders and Playlists.
- Search and sorting by title, artist, album or duration.
- Persistent user-created playlists, with per-track shortcuts to Play, Play next, Add to queue and Add to playlist.
- Mini-player play/pause, next, shuffle, repeat, progress indicator and current synced lyric line when available.
- Sleep timer: 5, 10, 15, 30, 45, 60 or 90 minutes, end of current track, and cancel.
- Adjustable song-list text size.
- FLAC source quality label from FLAC STREAMINFO metadata.
- Attempts to read synchronized LRC-style lyrics stored in common FLAC Vorbis-comment fields (`LYRICS`, `SYNCEDLYRICS`, etc.). The current line is shown above the mini-player progress line and in the optional full player.
- Background playback is owned by `PlaybackService` (AndroidX Media3 `MediaSessionService`), not the Activity.
- MediaSession metadata is attached to each track so Android can display track information and artwork in the media notification / lock screen. Standard session transport controls (play/pause, previous/next) are exposed to Android, Bluetooth and headset integrations.
- No streaming service, account or network access is used.

## Build in Android Studio

1. Install Android Studio with JDK 17 and Android SDK Platform 35.
2. Open this `LumaMusic` folder (the folder containing `settings.gradle.kts`).
3. Allow Gradle to sync and download the declared AndroidX / Compose dependencies.
4. Connect an Android 10+ device with USB debugging enabled, or create an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Install the debug APK from `app/build/outputs/apk/debug/app-debug.apk`.

Command line (after Gradle and Android SDK are installed):

```bash
gradle assembleDebug
```

## Important limitations — not yet a complete Poweramp/MusicBeat replacement

- This environment does not have Gradle or an Android SDK configured, and network access is unavailable to install them. Therefore an APK has **not** been compiled or device-tested. The supplied artifact is the Android Studio source project; notification and lock-screen integration is implemented in source but has not been runtime-verified on a device.
- Synced lyrics are currently read from common FLAC Vorbis-comment fields only. Sidecar `.lrc` files, ID3 SYLT/USLT lyrics, online lyric lookup and manual lyric editing are not implemented.
- Android Auto, gapless playback, ReplayGain, tag editing, embedded artwork editing, crossfade, audio effects / equalizer, widgets, advanced folder navigation, backup/export and extensive Poweramp-level settings are not implemented yet.
- The sleep timer and library playlists are implemented locally. Playlists are stored in app preferences and are not exported or backed up.
- The MediaSessionService integration is a functional implementation path, but it has not been compiled or device-tested in this environment. Treat this as an early development build rather than a finished daily-driver player.
- The FLAC badge describes source-file properties; it does not prove bit-perfect output through Android's audio mixer, Bluetooth, USB DAC or the complete audio chain.
- Actual codec support depends on the device's installed Android decoders.

## Project layout

- `MainActivity.kt` — Compose UI, library interaction, playlists, queue, sleep timer and playback controls
- `PlaybackService.kt` — background ExoPlayer, MediaSession and Android media notification / lock-screen integration
- `Library.kt` / `Track.kt` — MediaStore local-library scan and track model
- `Lyrics.kt` — embedded FLAC Vorbis-comment lyric reader and LRC timestamp parser
- `FlacQuality.kt` — FLAC STREAMINFO reader
